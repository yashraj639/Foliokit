const copyButtons = document.querySelectorAll(".copy-link");
const navToggle = document.getElementById("nav-toggle");
const nav = document.getElementById("nav");

copyButtons.forEach((button) => {
  button.addEventListener("click", async () => {
    const link = button.dataset.link;

    try {
      await navigator.clipboard.writeText(link);
      button.textContent = "Copied";

      window.setTimeout(() => {
        button.textContent = "Copy link";
      }, 1800);
    } catch {
      console.error("Failed to copy");
    }
  });
});

if (navToggle && nav) {
  navToggle.addEventListener("click", () => {
    navToggle.classList.toggle("active");
    nav.classList.toggle("active");
    document.body.style.overflow = nav.classList.contains("active") ? "hidden" : "";
  });

  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      navToggle.classList.remove("active");
      nav.classList.remove("active");
      document.body.style.overflow = "";
    });
  });
}