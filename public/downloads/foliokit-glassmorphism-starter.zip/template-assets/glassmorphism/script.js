document.addEventListener("DOMContentLoaded", () => {
  const cards = document.querySelectorAll(".work-card");

  cards.forEach((card) => {
    card.addEventListener("mouseenter", () => {
      card.style.transform = "translateY(-8px)";
    });

    card.addEventListener("mouseleave", () => {
      card.style.transform = "";
    });
  });

  const contactLink = document.querySelector('.link[href^="mailto"]');
  if (contactLink) {
    contactLink.addEventListener("click", () => {
      console.log("Contact link clicked");
    });
  }

  const navToggle = document.getElementById("nav-toggle");
  const nav = document.getElementById("nav");

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      navToggle.classList.toggle("active");
      nav.classList.toggle("active");
      document.body.style.overflow = nav.classList.contains("active") ? "hidden" : "";
    });

    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.classList.remove("active");
        nav.classList.remove("active");
        document.body.style.overflow = "";
      });
    });
  }
});