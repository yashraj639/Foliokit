const copyButton = document.getElementById("copy-email");
const navToggle = document.getElementById("nav-toggle");
const nav = document.getElementById("nav");

if (copyButton) {
  copyButton.addEventListener("click", async () => {
    const email = "ari@example.com";

    try {
      await navigator.clipboard.writeText(email);
      copyButton.textContent = "Copied";

      window.setTimeout(() => {
        copyButton.textContent = "Copy email";
      }, 1800);
    } catch {
      copyButton.textContent = email;
    }
  });
}

if (navToggle && nav) {
  navToggle.addEventListener("click", () => {
    navToggle.classList.toggle("active");
    nav.classList.toggle("active");
    document.body.style.overflow = nav.classList.contains("active") ? "hidden" : "";
  });

  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      navToggle.classList.remove("active");
      nav.classList.remove("active");
      document.body.style.overflow = "";
    });
  });
}
