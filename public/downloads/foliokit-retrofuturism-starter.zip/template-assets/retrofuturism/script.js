const copyButton = document.getElementById("copy-email");

if (copyButton) {
  copyButton.addEventListener("click", async () => {
    const email = "vera@example.com";

    try {
      await navigator.clipboard.writeText(email);
      copyButton.textContent = "Copied";

      window.setTimeout(() => {
        copyButton.textContent = "Copy email";
      }, 1800);
    } catch {
      copyButton.textContent = email;
    }
  });
}
